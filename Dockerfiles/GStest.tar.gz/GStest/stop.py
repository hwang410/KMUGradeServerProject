import os

for i in range(4):
	num=i+1
	os.system("sudo docker stop grade_container"+str(num))
	os.system("sudo docker rm grade_container"+str(num))
