import os
import time

t=time.time()

os.system('docker run --privileged --rm -it --name 222 tmp:0.2 python def.py')
#os.system('touch a.txt')
print time.time()-t
