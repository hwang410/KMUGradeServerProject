import os
import time

t=time.time()

os.system('docker run --rm centos:6 touch a.txt')


print time.time()-t
