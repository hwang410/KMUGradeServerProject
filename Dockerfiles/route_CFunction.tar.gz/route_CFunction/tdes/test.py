import sys
import chilkat

crypt = chilkat.CkCrypt2()

success = crypt.UnlockComponent("Anything for 30-day trial")
if (success != True):
    #  Unlock failed.
    print crypt.lastErrorText()
    sys.exit()

#  To get 3DES, set the algorithm = "des", and the
#  key length to 168 bits:
crypt.put_CryptAlgorithm("des")
crypt.put_KeyLength(168)

#  The encrypted output will be a hex-encoded string.
#  It is also possible to use "base64", "url" (for url-encoding), and other modes.
crypt.put_EncodingMode("hex")

#  Both ECB and CBC modes are available.
#  Use "ecb" for Electronic Cookbook Mode.
#  "cbc" is for Cipher-Block-Chaining.
crypt.put_CipherMode("cbc")

#  Initialization vectors should equal the block-size of the algorithm.
#  for 3DES (and DES) the block-size is 8 bytes.
#  The IV may be set from an encoded string:
crypt.SetEncodedIV("0102030405060708","hex")

#  (it is also possible to set the IV directly from a byte array...)

#  The secret key should have a length equal to the bit-strength of
#  the algorithm.   In this case, we have 168-bit 3DES.  However,
#  with DES (and 3DES) the most significant bit of each key byte is
#  a parity bit, and therefore 168-bits really refers to a 192-bit key
#  where the 24 msb's are parity bits.  Our 3DES key should be 24 bytes in size.
crypt.SetEncodedKey("010203040506070801020304050607080102030405060708","hex")

#  (it is also possible to set the key directly from a byte array, or generate
#  a key from a arbitrary-length string password.)

#  3DES is a block encryption algorithm.  This means that output is always
#  a multiple of the algorithm's block size.  For 3DES, the block size is 8 bytes.
#  Therefore, if your input is not a multiple of 8 bytes, it will be padded.
#  There are several choices for padding (consult the Chilkat Crypt reference).
#  We'll pad with SPACE (0x20) characters:
crypt.put_PaddingScheme(4)

#  Note: If trying to match the results produced by two different 3DES implementations,
#  make sure to test with data that is longer than a single block (8 bytes for 3DES).
#  If all params match (IV, secret key, cipher mode, etc.) except for the padding, then
#  the results will be identical except for the last block of output.  If you test data is only
#  a single block, you cannot recognize the situation where all is correct except
#  for a padding mismatch.

cipherText = crypt.encryptStringENC("Hwqazxcvg")
print cipherText
plainText = crypt.decryptStringENC(cipherText)
print plainText

#  Note: Because we used SPACE character padding, the output string will contain trailing SPACE
#  chars, which can easily be trimmed.

#  (Other padding schemes embed the original input length in the padding so that the Decrypt* methods always
#  return the exact original data).

