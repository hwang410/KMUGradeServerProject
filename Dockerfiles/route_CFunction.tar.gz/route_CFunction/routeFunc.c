#include <Python.h>

static PyObject *ErrorObject;

void RouteCat(char *str1, char *str2)
{
	char *temp;
	temp = strcat(str2, "/");

	strcat(str1, temp);
}

static PyObject* FileRouteFunc(PyObject *self, PyObject *args)
{
	char *courseName;
	char *classNum;
	char *stdNum;
	char *problemDirName;
	char className[15] = "class";

	char fileRoute[110] = "/home/algorithm/gradeserver/current/";

	if(!PyArg_ParseTuple(args, "ssss", &courseName, &classNum, &stdNum, &problemDirName))
		return NULL;

	strcat(className, classNum);

	RouteCat(fileRoute, courseName);
	RouteCat(fileRoute, className);
	RouteCat(fileRoute, stdNum);
	RouteCat(fileRoute, problemDirName);

	return Py_BuildValue("s", fileRoute);
}

static PyObject* AnswerDefaultRouteFunc(PyObject *self, PyObject *args)
{
	char fileRoute[110] = "/home/algorithm/gradeserver/problems/";

	return Py_BuildValue("s", fileRoute);
}

static PyObject* AnswerRouteFunc(PyObject *self, PyObject *args)
{
	char *problemDirName;

	char fileRoute[110] = "/home/algorithm/gradeserver/problems/";

	if(!PyArg_ParseTuple(args, "s", &problemDirName))
		return NULL;

	RouteCat(fileRoute, problemDirName);

	return Py_BuildValue("s", fileRoute);
}

static PyObject* DBRouteFunc(PyObject *self, PyObject *args)
{
	char dbRoute[70] = "mariadb://000.000.000.000/i/dont/know/";
	return Py_BuildValue("s", dbRoute);
}

static struct PyMethodDef routeFunc_methods[] = { {"FileRoute", FileRouteFunc, METH_VARARGS}, {"AnswerDefaultRoute", AnswerDefaultRouteFunc, METH_VARARGS},
						{"AnswerRoute", AnswerRouteFunc, METH_VARARGS}, {"DBRoute", DBRouteFunc, METH_VARARGS}, {NULL, NULL} };

void initroute()
{
	PyObject *module;

	module = Py_InitModule("route", routeFunc_methods);
	
	ErrorObject = Py_BuildValue("s", "route error");
}
