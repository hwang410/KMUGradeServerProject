from distutils.core import setup, Extension

setup(name = "route", version = "1.0", description = "route module", author = "H.S.J", ext_modules = [Extension("route", ["routeFunc.c"])])
